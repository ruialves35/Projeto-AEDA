var searchData=
[
  ['addcategoria_0',['addCategoria',['../class_buy_now.html#ab6325832bf49a3befbd9fd01064f35b1',1,'BuyNow']]],
  ['addcliente_1',['addCliente',['../class_buy_now.html#abd568d5147a45d19fa74b69e548fcfd4',1,'BuyNow']]],
  ['addlojafisica_2',['addLojaFisica',['../class_buy_now.html#a7d7b7d35da6563f2cd9812bfebaf1505',1,'BuyNow']]],
  ['addproduto_3',['addProduto',['../class_buy_now.html#a6835981633ca27e8a4fd90d9ae864a9f',1,'BuyNow::addProduto()'],['../class_loja_online.html#a90a6ba4529aa55505031554a048e3a0d',1,'LojaOnline::addProduto()'],['../class_transacao.html#ad251beccb20635c2ed2b8a2d07b8ca5c',1,'Transacao::addProduto()']]],
  ['addprodutolojafisica_4',['addProdutoLojaFisica',['../class_buy_now.html#ac3b151679c88976d6174c00fd1325989',1,'BuyNow::addProdutoLojaFisica(LojaFisica &amp;lf, Produto *p, int quantidade=1)'],['../class_buy_now.html#a1969da5233130e954d435a02fc299de7',1,'BuyNow::addProdutoLojaFisica(string localidade, Produto *p, int quantidade=1)']]],
  ['addprodutoonline_5',['addProdutoOnline',['../class_buy_now.html#a93c095601c695c44a99faaf4e03f9abd',1,'BuyNow']]],
  ['addprodutototransacao_6',['addProdutoToTransacao',['../class_loja_online.html#a884c9ad756ca3185c3c2fa3c4d7d8457',1,'LojaOnline']]],
  ['addreposicao_7',['addReposicao',['../class_buy_now.html#a7b2d3bcde56ebffb7491c3b72a9dcb85',1,'BuyNow']]],
  ['addtransacao_8',['addTransacao',['../class_buy_now.html#a8e0c33ecdd523589b088a495eff4823e',1,'BuyNow::addTransacao()'],['../class_loja_online.html#a5eda28158d75e0626f2ce35f5545ba1c',1,'LojaOnline::addTransacao()']]],
  ['addtransferencia_9',['addTransferencia',['../class_buy_now.html#a8fbd54a90d98ede43f8d7da3c3b1c895',1,'BuyNow']]],
  ['administrador_10',['administrador',['../class_buy_now_u_i.html#aad92f2c4daef3f706ecd74fc511437b0',1,'BuyNowUI']]]
];
