var searchData=
[
  ['produto_232',['Produto',['../class_produto.html#adcd5834a1f04cc42fef88bf60217b8f4',1,'Produto::Produto()'],['../class_produto.html#aeed879ca30b7fbd9ea0af2c218f63a1e',1,'Produto::Produto(string nome, int id, double val, Categoria categoria)']]]
];
