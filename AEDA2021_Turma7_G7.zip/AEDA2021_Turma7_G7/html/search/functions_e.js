var searchData=
[
  ['transacao_285',['Transacao',['../class_transacao.html#a720b1c7f661573d7717ea5dead5e7096',1,'Transacao::Transacao()'],['../class_transacao.html#a175f5c25159fc19e1a349fee8d884658',1,'Transacao::Transacao(Cliente *c, Date &amp;d)'],['../class_transacao.html#a323728c7fd0386d240d09d5ae908af17',1,'Transacao::Transacao(Cliente *c, Date &amp;d, vector&lt; Produto * &gt; &amp;v)'],['../class_transacao.html#a3a07d5fdef4e30d92102e1a2591d669b',1,'Transacao::Transacao(Cliente *c, Date &amp;d, vector&lt; Produto * &gt; &amp;v, Pagamento *p)']]],
  ['transferencia_286',['Transferencia',['../class_transferencia.html#a647149cd0c7b011f08258949f933ab8f',1,'Transferencia::Transferencia()'],['../class_transferencia.html#afd18b08512de0c427e4132149545fbb5',1,'Transferencia::Transferencia(Fornecedor &amp;f, Produto *p, int quantidade, Date data)']]]
];
