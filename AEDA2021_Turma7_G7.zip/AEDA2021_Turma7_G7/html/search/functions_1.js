var searchData=
[
  ['buynow_169',['BuyNow',['../class_buy_now.html#a2dc3e27e45ad6c5a9074584dafdbc22b',1,'BuyNow::BuyNow()'],['../class_buy_now.html#aa405ea9e2c5554f6e73b3bb8281320fb',1,'BuyNow::BuyNow(vector&lt; LojaFisica &gt; &amp;lf, LojaOnline &amp;lo, int stockOk, int stockMin)'],['../class_buy_now.html#a1c38b20d8f49e9cbfd677ac682f90ad0',1,'BuyNow::BuyNow(vector&lt; LojaFisica &gt; &amp;lf, LojaOnline &amp;lo, vector&lt; Transferencia * &gt; tranferencias, int stockOk, int stockMin)']]]
];
