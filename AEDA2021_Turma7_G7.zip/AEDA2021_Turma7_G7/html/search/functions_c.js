var searchData=
[
  ['removecategoria_233',['removeCategoria',['../class_buy_now.html#ae490762fba6e4edfbe1decfea4d3ef23',1,'BuyNow']]],
  ['removecliente_234',['removeCliente',['../class_buy_now.html#abb379e1f4dcd0d06ec0f1fd4113945cb',1,'BuyNow::removeCliente(string nome, int numContribuinte)'],['../class_buy_now.html#ae6e0ee00d814f8cc51556407276ec19c',1,'BuyNow::removeCliente(Cliente *cliente)']]],
  ['removelojafisica_235',['removeLojaFisica',['../class_buy_now.html#a6764eb40eb9279401f1108b773f9c653',1,'BuyNow']]],
  ['removeproduto_236',['removeProduto',['../class_buy_now.html#aa4978380eca31721e457117a11b3cc13',1,'BuyNow::removeProduto()'],['../class_loja_fisica.html#aa17bc26bd638e8e83c23b9d917c5fc4d',1,'LojaFisica::removeProduto()'],['../class_loja_online.html#a5936914540d7cba6f6e304ccc3a8ffcc',1,'LojaOnline::removeProduto()'],['../class_transacao.html#a42c70db0855046c1f343cfb6d47c1d0a',1,'Transacao::removeProduto(Produto *p)'],['../class_transacao.html#a28790c24a89b0544c8ae6a195deed2a4',1,'Transacao::removeProduto(Produto *p, int quantidade)']]],
  ['removeprodutolojafisica_237',['removeProdutoLojaFisica',['../class_buy_now.html#a811f3d528492adbf443168ffafaa90e4',1,'BuyNow']]],
  ['removeprodutooftransacao_238',['removeProdutoOfTransacao',['../class_loja_online.html#a78510ba22429545f280bc1d9e2b248a6',1,'LojaOnline']]],
  ['removeprodutoonline_239',['removeProdutoOnline',['../class_buy_now.html#a9284c33c2025fdf5e861a7b6a783f7a6',1,'BuyNow']]],
  ['removetransacao_240',['removeTransacao',['../class_buy_now.html#a0962d6130f7af82de71f030d1991a75e',1,'BuyNow::removeTransacao()'],['../class_loja_online.html#ae03d29e3d30682f9bba4d2bf7e8b1196',1,'LojaOnline::removeTransacao()']]],
  ['removetransferencia_241',['removeTransferencia',['../class_buy_now.html#a6c825241760d8ebdc62a91dd85e4819f',1,'BuyNow']]],
  ['reporstock_242',['reporStock',['../class_buy_now.html#a2b4f92d00c4c26a57134e9c4d2921ce4',1,'BuyNow']]],
  ['reposicao_243',['Reposicao',['../class_reposicao.html#a7d3a647091bbf437d332a91e62f207b5',1,'Reposicao::Reposicao()'],['../class_reposicao.html#a5622c59c0a820717d908e0fd85281619',1,'Reposicao::Reposicao(LojaFisica lf, Produto *p, int quantidade, Date data)']]]
];
