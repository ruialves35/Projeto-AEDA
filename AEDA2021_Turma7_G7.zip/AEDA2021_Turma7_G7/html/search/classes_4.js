var searchData=
[
  ['lojafisica_147',['LojaFisica',['../class_loja_fisica.html',1,'']]],
  ['lojafisicadoesnotexist_148',['LojaFisicaDoesNotExist',['../class_loja_fisica_does_not_exist.html',1,'']]],
  ['lojaonline_149',['LojaOnline',['../class_loja_online.html',1,'']]]
];
