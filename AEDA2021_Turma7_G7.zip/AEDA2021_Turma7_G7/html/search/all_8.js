var searchData=
[
  ['lojafisica_71',['LojaFisica',['../class_loja_fisica.html',1,'LojaFisica'],['../class_loja_fisica.html#a185fcab51de5c5252d9e8ae4232f58e3',1,'LojaFisica::LojaFisica()'],['../class_loja_fisica.html#a54471845f5c01cc1453d0d9aaf8075ce',1,'LojaFisica::LojaFisica(string localidade)']]],
  ['lojafisicadoesnotexist_72',['LojaFisicaDoesNotExist',['../class_loja_fisica_does_not_exist.html',1,'']]],
  ['lojaonline_73',['LojaOnline',['../class_loja_online.html',1,'LojaOnline'],['../class_loja_online.html#a22d5cf7adaba54878310842e76c47b62',1,'LojaOnline::LojaOnline()']]]
];
