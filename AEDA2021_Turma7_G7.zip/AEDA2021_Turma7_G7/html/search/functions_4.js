var searchData=
[
  ['escreverlojaonline_176',['escreverLojaOnline',['../class_buy_now_u_i.html#a8ce0168c04557990dce3e26b2bb3b7b3',1,'BuyNowUI']]],
  ['escreverreposicoes_177',['escreverReposicoes',['../class_buy_now_u_i.html#a5fcd4986593c16224d771d32a966006b',1,'BuyNowUI']]],
  ['escrevertransacoes_178',['escreverTransacoes',['../class_buy_now_u_i.html#a845d40db2f8e603a09299c71a22f07c8',1,'BuyNowUI']]],
  ['escrevertransferencias_179',['escreverTransferencias',['../class_buy_now_u_i.html#a0afd665221abdfde0d92056d657a965f',1,'BuyNowUI']]]
];
