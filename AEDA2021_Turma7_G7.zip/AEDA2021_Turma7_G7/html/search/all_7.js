var searchData=
[
  ['isleap_69',['isLeap',['../class_date.html#a80c7491dabb72297106f26967518fc31',1,'Date']]],
  ['isvalid_70',['isValid',['../class_date.html#a7d9aaa9db591413e21c8b85fdae130ad',1,'Date']]]
];
