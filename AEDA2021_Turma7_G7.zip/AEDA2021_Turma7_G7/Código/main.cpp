#include <iostream>
#include "Date.h"
#include "Transacao.h"
#include "BuyNowUI.h"

void testDate(){
    Date d1(29,2,2020);
    cout << d1;
    return;
}


int main() {
    BuyNowUI teste;

    //testDate();
    return 0;
}

