# Projeto-AEDA
 
A Empresa tem um Fornecedor que é universal a todos os produtos. Este Fornecedor foi pré-definido com o nome "Manel".

Os produtos da Loja Online têm um stock minimo pré-definido (1ª linha do ficheiro Online.txt).
Os produtos das Lojas Fisicas têm um stock Ok pré-definido (2ª linha do ficheiro Online.txt)

As Transações são compras feitas pelo Cliente à Loja Online.
As Reposições são reposições de stock de um Produto da Loja Online por uma Loja Fisica (buscar produto a uma Loja Fisica).
As Transferências são compras feitas pela Empresa ao Fornecedor para repor o stock de um Produto (a quantidade necessária não estava
disponível em nenhuma Loja Fisica).

Caso não esteja a dar para ler ficheiros, introduzir os mesmos na pasta cmake-build-debug.